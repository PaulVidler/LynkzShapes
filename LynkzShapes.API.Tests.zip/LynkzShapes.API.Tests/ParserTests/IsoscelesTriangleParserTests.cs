﻿using LynkzShapes.ShapeParsers.ComplexShapes;

namespace IsoscelesTriangleParser.Tests
{
    [TestFixture]
    public class IsoscelesTriangleDimensionsParserTests
    {
        [Test]
        public void ParseShape_ValidInput1_ReturnsExpectedDictionary()
        {
            string input = "I want an Isosceles triangle with a width of 100 and a height of 200";

            Dictionary<string, double> result = IsoscelesTriangleDimensionsParser.ParseShape(input);

            Assert.AreEqual(2, result.Count);
            Assert.IsTrue(result.ContainsKey("Base Length"));
            Assert.IsTrue(result.ContainsKey("Height"));
            Assert.AreEqual(100, result["Base Length"]);
            Assert.AreEqual(200, result["Height"]);
        }

        [Test]
        public void ParseShape_ValidInput2_ReturnsExpectedDictionary()
        {
            string input = "Draw me an Isosceles triangle with a width of 100 and a height of 200";

            Dictionary<string, double> result = IsoscelesTriangleDimensionsParser.ParseShape(input);

            Assert.AreEqual(2, result.Count);
            Assert.IsTrue(result.ContainsKey("Base Length"));
            Assert.IsTrue(result.ContainsKey("Height"));
            Assert.AreEqual(100, result["Base Length"]);
            Assert.AreEqual(200, result["Height"]);
        }

        [Test]
        public void ParseShape_ValidInput4_ReturnsExpectedDictionary()
        {
            string input = "Draw me a Isosceles triangle 100 wide and 200 high";

            Dictionary<string, double> result = IsoscelesTriangleDimensionsParser.ParseShape(input);

            Assert.AreEqual(2, result.Count);
            Assert.IsTrue(result.ContainsKey("Base Length"));
            Assert.IsTrue(result.ContainsKey("Height"));
            Assert.AreEqual(100, result["Base Length"]);
            Assert.AreEqual(200, result["Height"]);
        }

    }
}

