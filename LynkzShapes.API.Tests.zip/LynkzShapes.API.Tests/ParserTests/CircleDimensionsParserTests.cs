﻿using LynkzShapes.ShapeParsers.ComplexShapes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LynkzShapes.API.Tests.ParserTests
{
    [TestFixture]
    public class CircleDimensionsParserTests
    {
        [Test]
        public void ParseShape_ValidDiameterInput_ReturnsExpectedDictionary()
        {
            string input = "I want a circle with a diameter of 200";

            Dictionary<string, double> result = CircleDimensionsParser.ParseShape(input);

            Assert.That(result.Count, Is.EqualTo(1));
            Assert.IsTrue(result.ContainsKey("Radius"));
            Assert.That(result["Radius"], Is.EqualTo(100));
        }

        [Test]
        public void ParseShape_ValidRadiusInput_ReturnsExpectedDictionary()
        {
            string input = "I want a circle with a radius of 100";

            Dictionary<string, double> result = CircleDimensionsParser.ParseShape(input);

            Assert.That(result.Count, Is.EqualTo(1));
            Assert.IsTrue(result.ContainsKey("Radius"));
            Assert.That(result["Radius"], Is.EqualTo(100));
        }
    }
}
