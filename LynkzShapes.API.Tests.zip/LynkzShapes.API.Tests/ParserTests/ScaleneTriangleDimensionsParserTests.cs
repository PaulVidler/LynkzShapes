﻿using LynkzShapes.ShapeParsers.ComplexShapes;

namespace ScaleneTriangleParser.Tests
{
    [TestFixture]
    public class ScaleneTriangleDimensionsParserTests
    {
        [Test]
        public void ParseShape_ValidInput1_ReturnsExpectedDictionary()
        {
            string input = "draw me a scalene triangle with side A of 200 and side B of 300 and side C of 400";

            Dictionary<string, double> result = ScaleneTriangleDimensionsParser.ParseShape(input);

            Assert.That(result.Count, Is.EqualTo(3));
            Assert.IsTrue(result.ContainsKey("SideA"));
            Assert.IsTrue(result.ContainsKey("SideB"));
            Assert.IsTrue(result.ContainsKey("SideC"));
            Assert.That(result["SideA"], Is.EqualTo(200));
            Assert.That(result["SideB"], Is.EqualTo(300));
            Assert.That(result["SideC"], Is.EqualTo(400));
        }
    }
}

