﻿using LynkzShapes.ShapeParsers.ComplexShapes;
using NUnit.Framework;
using System.Collections.Generic;

namespace ParallelogramParser.Tests
{
    [TestFixture]
    public class ParallelogramDimensionsParserTests
    {
        [Test]
        public void ParseShape_ValidInput1_ReturnsExpectedDictionary()
        {
            string input = "I want a parallelogram with a width of 100 and a height of 200 and a skew of 22";

            Dictionary<string, double> result = ParallelogramDimensionsParser.ParseShape(input);

            Assert.That(result.Count, Is.EqualTo(3));
            Assert.IsTrue(result.ContainsKey("Width"));
            Assert.IsTrue(result.ContainsKey("Height"));
            Assert.IsTrue(result.ContainsKey("Skew"));
            Assert.That(result["Width"], Is.EqualTo(100));
            Assert.That(result["Height"], Is.EqualTo(200));
            Assert.That(result["Skew"], Is.EqualTo(22));
        }

        [Test]
        public void ParseShape_ValidInput2_ReturnsExpectedDictionary()
        {
            string input = "Draw me a parallelogram with a width of 100 and a height of 200 and a skew of 22";

            Dictionary<string, double> result = ParallelogramDimensionsParser.ParseShape(input);

            Assert.That(result.Count, Is.EqualTo(3));
            Assert.IsTrue(result.ContainsKey("Width"));
            Assert.IsTrue(result.ContainsKey("Height"));
            Assert.IsTrue(result.ContainsKey("Skew"));
            Assert.That(result["Width"], Is.EqualTo(100));
            Assert.That(result["Height"], Is.EqualTo(200));
            Assert.That(result["Skew"], Is.EqualTo(22));
        }

        [Test]
        public void ParseShape_ValidInput3_ReturnsExpectedDictionary()
        {
            string input = "I want a parallelogram 100 wide and 200 high and a skew of 22";

            Dictionary<string, double> result = ParallelogramDimensionsParser.ParseShape(input);

            Assert.That(result.Count, Is.EqualTo(3));
            Assert.IsTrue(result.ContainsKey("Width"));
            Assert.IsTrue(result.ContainsKey("Height"));
            Assert.IsTrue(result.ContainsKey("Skew"));
            Assert.That(result["Width"], Is.EqualTo(100));
            Assert.That(result["Height"], Is.EqualTo(200));
            Assert.That(result["Skew"], Is.EqualTo(22));
        }

        [Test]
        public void ParseShape_ValidInput4_ReturnsExpectedDictionary()
        {
            string input = "Draw me a parallelogram 100 wide and 200 high and a skew of 22";

            Dictionary<string, double> result = ParallelogramDimensionsParser.ParseShape(input);

            Assert.That(result.Count, Is.EqualTo(3));
            Assert.IsTrue(result.ContainsKey("Width"));
            Assert.IsTrue(result.ContainsKey("Height"));
            Assert.IsTrue(result.ContainsKey("Skew"));
            Assert.That(result["Width"], Is.EqualTo(100));
            Assert.That(result["Height"], Is.EqualTo(200));
            Assert.That(result["Skew"], Is.EqualTo(22));
        }
    }
}
