﻿using LynkzShapes.ShapeParsers.ComplexShapes;

namespace OvalParser.Tests
{
    [TestFixture]
    public class OvalDimensionsParserTests
    {
        [Test]
        public void ParseShape_ValidInput1_ReturnsExpectedDictionary()
        {
            string input = "I want an oval with a width of 200 and a height of 100";

            Dictionary<string, double> result = OvalDimensionsParser.ParseShape(input);

            Assert.That(result.Count, Is.EqualTo(2));
            Assert.IsTrue(result.ContainsKey("Width"));
            Assert.IsTrue(result.ContainsKey("Height"));
            Assert.That(result["Width"], Is.EqualTo(200));
            Assert.That(result["Height"], Is.EqualTo(100));
        }

        [Test]
        public void ParseShape_ValidInput2_ReturnsExpectedDictionary()
        {
            string input = "Draw me an oval with a width of 200 and a height of 100";

            Dictionary<string, double> result = OvalDimensionsParser.ParseShape(input);

            Assert.That(result.Count, Is.EqualTo(2));
            Assert.IsTrue(result.ContainsKey("Width"));
            Assert.IsTrue(result.ContainsKey("Height"));
            Assert.That(result["Width"], Is.EqualTo(200));
            Assert.That(result["Height"], Is.EqualTo(100));
        }
    }
}
