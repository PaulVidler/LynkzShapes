﻿
using LynkzShapes.ShapeParsers.ComplexShapes;
using NUnit.Framework;
using System.Collections.Generic;

namespace RectangleParser.Tests
{
    [TestFixture]
    public class RectangleDimensionsParserTests
    {
        [Test]
        public void ParseShape_ValidInput1_ReturnsExpectedDictionary()
        {
            string input = "I want a rectangle with a width of 100 and a height of 200";

            Dictionary<string, double> result = RectangleDimensionsParser.ParseShape(input);

            Assert.That(result.Count, Is.EqualTo(2));
            Assert.IsTrue(result.ContainsKey("Width"));
            Assert.IsTrue(result.ContainsKey("Height"));
            Assert.That(result["Width"], Is.EqualTo(100));
            Assert.That(result["Height"], Is.EqualTo(200));
        }

        [Test]
        public void ParseShape_ValidInput2_ReturnsExpectedDictionary()
        {
            string input = "Draw me a rectangle with a width of 100 and a height of 200";

            Dictionary<string, double> result = RectangleDimensionsParser.ParseShape(input);

            Assert.That(result.Count, Is.EqualTo(2));
            Assert.IsTrue(result.ContainsKey("Width"));
            Assert.IsTrue(result.ContainsKey("Height"));
            Assert.That(result["Width"], Is.EqualTo(100));
            Assert.That(result["Height"], Is.EqualTo(200));
        }

        [Test]
        public void ParseShape_ValidInput3_ReturnsExpectedDictionary()
        {
            string input = "I want a rectangle a 100 wide and 200 high";

            Dictionary<string, double> result = RectangleDimensionsParser.ParseShape(input);

            Assert.That(result.Count, Is.EqualTo(2));
            Assert.IsTrue(result.ContainsKey("Width"));
            Assert.IsTrue(result.ContainsKey("Height"));
            Assert.That(result["Width"], Is.EqualTo(100));
            Assert.That(result["Height"], Is.EqualTo(200));
        }

        [Test]
        public void ParseShape_ValidInput4_ReturnsExpectedDictionary()
        {
            string input = "Draw me a rectangle 100 wide and 200 high";

            Dictionary<string, double> result = RectangleDimensionsParser.ParseShape(input);

            Assert.That(result.Count, Is.EqualTo(2));
            Assert.IsTrue(result.ContainsKey("Width"));
            Assert.IsTrue(result.ContainsKey("Height"));
            Assert.That(result["Width"], Is.EqualTo(100));
            Assert.That(result["Height"], Is.EqualTo(200));
        }
    }
}

