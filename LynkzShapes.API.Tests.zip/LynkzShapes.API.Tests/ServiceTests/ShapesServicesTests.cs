﻿using NUnit.Framework;
using Moq;
using System.Collections.Generic;
using LynkzShapes.Factories;
using LynkzShapes.LynkzShapes.Models;
using LynkzShapes.LynkzShapes.Services;

namespace ShapeService.Tests
{
    [TestFixture]
    public class ShapeServiceTests
    {
        [Test]
        public void CreateShapeFromDescription_ValidShape_ReturnsCorrectResult()
        {
            var shapeFactoryMock = new Mock<IShapeFactory>();
            var shapeMock = new Mock<IShape>();
            shapeMock.Setup(s => s.GetShapeType()).Returns("Triangle");
            shapeMock.Setup(s => s.GetDimensions()).Returns(new Dictionary<string, double>
            {
                { "SideA", 3.0 },
                { "SideB", 4.0 },
                { "SideC", 5.0 }
            });

            shapeFactoryMock.Setup(factory => factory.CreateShape(It.IsAny<string>())).Returns(shapeMock.Object);

            var shapeService = new LynkzShapes.Services.ShapeService(shapeFactoryMock.Object);

            string shapeDescription = "draw me a triangle with sideA of 3 and sideB of 4 and sideC of 5";

            ShapeCreationResult result = shapeService.CreateShapeFromDescription(shapeDescription);

            Assert.That(result.ShapeType, Is.EqualTo("Triangle"));
            Assert.IsNotNull(result.ShapeDimensions);
            Assert.That(result.ShapeDimensions["SideA"], Is.EqualTo(3.0));
            Assert.That(result.ShapeDimensions["SideB"], Is.EqualTo(4.0));
            Assert.That(result.ShapeDimensions["SideC"], Is.EqualTo(5.0));
            Assert.IsNull(result.ErrorMessage);
        }

        [Test]
        public void CreateShapeFromDescription_InvalidShape_ReturnsErrorResult()
        {
            var shapeFactoryMock = new Mock<IShapeFactory>();
            shapeFactoryMock.Setup(factory => factory.CreateShape(It.IsAny<string>())).Returns((IShape)null);

            var shapeService = new LynkzShapes.Services.ShapeService(shapeFactoryMock.Object);

            string shapeDescription = "invalid shape description";

            ShapeCreationResult result = shapeService.CreateShapeFromDescription(shapeDescription);

            Assert.IsNull(result.ShapeType);
            Assert.IsNull(result.ShapeDimensions);
            Assert.That(result.ErrorMessage, Is.EqualTo("There seems to have been an error interpreting your requirement, try using the guide before asking another question"));
        }

        [Test]
        public void CreateShapeFromDescription_ExceptionThrown_ReturnsErrorResult()
        {
            var shapeFactoryMock = new Mock<IShapeFactory>();
            shapeFactoryMock.Setup(factory => factory.CreateShape(It.IsAny<string>())).Throws(new System.Exception("Some error"));

            var shapeService = new LynkzShapes.Services.ShapeService(shapeFactoryMock.Object);

            string shapeDescription = "some shape description";

            ShapeCreationResult result = shapeService.CreateShapeFromDescription(shapeDescription);

            Assert.IsNull(result.ShapeType);
            Assert.IsNull(result.ShapeDimensions);
            Assert.That(result.ErrorMessage, Is.EqualTo("Error creating shape: Some error"));
        }
    }
}

