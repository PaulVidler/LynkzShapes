﻿using NUnit.Framework;
using LynkzShapes.Helpers; // Replace with the actual namespace of ShapeNameParser

namespace ShapeNameParser.Tests
{
    [TestFixture]
    public class ShapeNameParserTests
    {
        [TestCase("I want to draw a circle")]
        [TestCase("Please create a circl")]
        public void ExtractShape_ValidCircleVariations_ReturnsCircle(string sentence)
        {
            string shape = LynkzShapes.Helpers.ShapeNameParser.ExtractShape(sentence);

            Assert.That(shape, Is.EqualTo("circle"));
        }

        [TestCase("Build me a square")]
        [TestCase("I need a sqaure")]
        public void ExtractShape_ValidSquareVariations_ReturnsSquare(string sentence)
        {
            string shape = LynkzShapes.Helpers.ShapeNameParser.ExtractShape(sentence);

            Assert.That(shape, Is.EqualTo("square"));
        }


        [TestCase("Blah blah random sentence")]
        [TestCase("No shape mentioned here only pork chops")]
        public void ExtractShape_NoMatchingShape_ReturnsNull(string sentence)
        {
            string shape = LynkzShapes.Helpers.ShapeNameParser.ExtractShape(sentence);

            Assert.IsNull(shape);
        }
    }
}

