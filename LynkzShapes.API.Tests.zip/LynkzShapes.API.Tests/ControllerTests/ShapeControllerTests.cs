﻿using LynkzShapes.Controllers;
using LynkzShapes.Dtos;
using LynkzShapes.LynkzShapes.Services;
using LynkzShapes.Services;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace LynkzShapes.API.Tests.ControllerTests
{
    namespace LynkzShapes.Tests
    {
        [TestFixture]
        public class ShapesControllerTests
        {
            private ShapesController _shapesController;
            private Mock<IShapeService> _mockShapeService;

            [SetUp]
            public void Setup()
            {
                _mockShapeService = new Mock<IShapeService>();
                _shapesController = new ShapesController(_mockShapeService.Object);
            }

            [Test]
            public void CreateShape_ValidRequest_ReturnsOkResult()
            {
                // Arrange
                var shapeRequest = new ShapeRequest { ShapeDescription = "valid description" };
                var shapeCreationResult = new ShapeCreationResult { ShapeType = "Circle" };

                _mockShapeService.Setup(service => service.CreateShapeFromDescription(shapeRequest.ShapeDescription))
                                 .Returns(shapeCreationResult);

                // Act
                var result = _shapesController.CreateShape(shapeRequest);

                // Assert
                Assert.IsInstanceOf<OkObjectResult>(result.Result);
                var okResult = result.Result as OkObjectResult;
                Assert.AreEqual(shapeCreationResult, okResult.Value);
            }

            [Test]
            public void CreateShape_InvalidRequest_ReturnsBadRequest()
            {
                // Arrange
                var shapeRequest = new ShapeRequest { ShapeDescription = "invalid description" };
                var shapeCreationResult = new ShapeCreationResult { ErrorMessage = "Invalid description format" };

                _mockShapeService.Setup(service => service.CreateShapeFromDescription(shapeRequest.ShapeDescription))
                                 .Returns(shapeCreationResult);

                // Act
                var result = _shapesController.CreateShape(shapeRequest);

                // Assert
                Assert.IsInstanceOf<BadRequestObjectResult>(result.Result);
                var badRequestResult = result.Result as BadRequestObjectResult;
                Assert.AreEqual(shapeCreationResult.ErrorMessage, badRequestResult.Value);
            }
        }
    }

}
