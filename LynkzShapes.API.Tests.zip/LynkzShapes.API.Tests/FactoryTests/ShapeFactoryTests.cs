﻿using LynkzShapes.LynkzShapes.Models;

namespace ShapeFactory.Tests
{
    [TestFixture]
    public class ShapeFactoryTests
    {
        [Test]
        public void CreateShape_InvalidDescription_ReturnsNull()
        {
            var factory = new LynkzShapes.Factories.ShapeFactory();
            string shapeDescription = "this is not a valid shape description";

            IShape shape = factory.CreateShape(shapeDescription);

            Assert.IsNull(shape);
        }
    }
}

